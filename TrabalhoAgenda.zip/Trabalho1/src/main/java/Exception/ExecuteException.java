package Exception;

public class ExecuteException extends Exception{


    public ExecuteException(String mensagem) {
        super(mensagem);
    }

}
